//ccomportamiento de la pagina
import Cliente from "./cliente.js"
import Impuesto from "./impuesto.js"
// var resultado       // revisar donde van las variables
// let i2 = new Impuesto(monto, deducciones)
// let c2 = new Cliente(cliente, i2)

// main.js
const btn = document.getElementById('calcular')
const result = document.getElementById('resultado')
btn.addEventListener('click', () =>{
  const cliente = document.getElementById('cliente').value;
  const monto = document.getElementById('monto').value;
  const deducciones = document.getElementById('deducciones').value;
i2 = new Impuesto(monto, deducciones)
c2 = new Cliente(cliente, i2)
    c2.calcularImpuesto(parseInt(monto), parseInt(deducciones))
})
