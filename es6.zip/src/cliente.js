export default Cliente
//clases.js
class Cliente {
    constructor(name, Impuesto) {
        this.name = name
        this.Impuesto = Impuesto
    }
    set name(newName) {
        this._name = newName
    }
    get name() {
        return this._name
    }
//calc.js
    calcularImpuesto () {
        console.log(c2)
        console.log(i2)
        resultado = (this.Impuesto.monto - this.Impuesto.deducciones) * (21/100)
        result.innerHTML = resultado
        return console.log(resultado)
    }
}
